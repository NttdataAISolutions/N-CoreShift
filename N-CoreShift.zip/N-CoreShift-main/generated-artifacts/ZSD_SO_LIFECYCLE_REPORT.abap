*&---------------------------------------------------------------------*
*& Report  ZSD_SO_LIFECYCLE_REPORT
*& Title:  Sales Order Lifecycle Report (Refactored - ECC Compatible)
*&
*& Purpose:
*&   Extracts Sales Order -> Delivery -> Invoice lifecycle data and exports
*&   a tab-delimited UTF-8 file via SAP GUI foreground download.
*&
*& Document-Flow Strategy:
*&   Document relationships are resolved via VBFA instead of OR-joined
*&   invoice conditions. This prevents duplicate rows and correctly handles
*&   partial deliveries, multiple invoices, and direct billing scenarios.
*&
*& Platform: SAP ECC 6.0 EhP7+
*& NOT S/4HANA Public Cloud compatible as-is (see Technical Review Notes)
*&
*& Test Scenarios Supported:
*&   1. SO with no delivery and no invoice     -> row with blank deliv/inv fields
*&   2. SO with delivery but no invoice        -> row with blank invoice fields
*&   3. SO with one delivery and one invoice   -> standard row
*&   4. SO with multiple partial deliveries    -> one row per delivery item
*&   5. SO with multiple invoices              -> one row per invoice
*&   6. SO billed directly (no delivery)       -> row with blank delivery fields
*&   7. Background execution                   -> blocked with clear error
*&   8. Invalid output path                    -> handled with specific messages
*&   9. Excessively broad date range           -> blocked with clear error
*&  10. No matching sales orders               -> informational message, no file
*&---------------------------------------------------------------------*
REPORT zsd_so_lifecycle_report
  LINE-SIZE 255
  NO STANDARD PAGE HEADING.

*----------------------------------------------------------------------*
* TYPE DECLARATIONS
*----------------------------------------------------------------------*
TYPES:
  "-- Raw sales-order item from VBAK + VBAP
  BEGIN OF ty_so_item,
    vbeln  TYPE vbak-vbeln,
    posnr  TYPE vbap-posnr,
    erdat  TYPE vbak-erdat,
    auart  TYPE vbak-auart,
    kunnr  TYPE vbak-kunnr,
    matnr  TYPE vbap-matnr,
    kwmeng TYPE vbap-kwmeng,
    vrkme  TYPE vbap-vrkme,
  END OF ty_so_item,

  "-- VBFA document flow entry (fields required for lifecycle resolution)
  BEGIN OF ty_vbfa,
    vbelv   TYPE vbfa-vbelv,
    posnv   TYPE vbfa-posnv,
    vbeln   TYPE vbfa-vbeln,
    posnn   TYPE vbfa-posnn,
    vbtyp_n TYPE vbfa-vbtyp_n,
  END OF ty_vbfa,

  "-- Delivery item from LIPS
  BEGIN OF ty_deliv,
    vbeln  TYPE lips-vbeln,
    posnr  TYPE lips-posnr,
    lfimg  TYPE lips-lfimg,
  END OF ty_deliv,

  "-- Billing item joined with header currency from VBRP + VBRK
  BEGIN OF ty_billed,
    vbeln  TYPE vbrp-vbeln,
    posnr  TYPE vbrp-posnr,
    fkimg  TYPE vbrp-fkimg,
    netwr  TYPE vbrp-netwr,
    waerk  TYPE vbrk-waerk,
  END OF ty_billed,

  "-- Final output row (all date/numeric fields as stable strings)
  BEGIN OF ty_output,
    sales_doc   TYPE vbak-vbeln,
    so_item     TYPE vbap-posnr,
    create_date TYPE string,    "YYYY-MM-DD
    doc_type    TYPE vbak-auart,
    customer    TYPE vbak-kunnr,
    material    TYPE vbap-matnr,
    order_qty   TYPE string,    "Decimal, no user-format separators
    uom         TYPE vbap-vrkme,
    deliv_doc   TYPE lips-vbeln,
    deliv_item  TYPE lips-posnr,
    deliv_qty   TYPE string,
    invoice_doc TYPE vbrp-vbeln,
    invoice_qty TYPE string,
    net_val     TYPE string,
    currency    TYPE vbrk-waerk,
  END OF ty_output.

*----------------------------------------------------------------------*
* CONSTANTS
*----------------------------------------------------------------------*
CONSTANTS:
  "-- Maximum allowed date range in days to prevent full-table scans.
  "   Increase only after verifying VBAK index performance for your volume.
  gc_max_date_range TYPE i            VALUE 366,

  "-- Maximum output rows. Report aborts with message if exceeded.
  gc_max_records    TYPE i            VALUE 500000,

  "-- VBFA subsequent-document category for Delivery documents.
  "   'J' = Standard outbound delivery (LF).
  "   TODO: Confirm with SD consultant whether 'T' (returns delivery) or
  "   other delivery types should also be included for your business process.
  gc_vbtyp_delivery TYPE vbfa-vbtyp_n VALUE 'J',

  "-- VBFA subsequent-document category for Billing/Invoice documents.
  "   'M' = Standard invoice.
  "   NOTE: Credit memos ('O'), debit memos ('P'), and cancellation billing
  "   documents ('S') are excluded by default.
  "   TODO: Confirm inclusion/exclusion rules with SD functional consultant.
  gc_vbtyp_invoice  TYPE vbfa-vbtyp_n VALUE 'M',

  "-- Tab character used as column delimiter in output file
  gc_tab            TYPE c            VALUE cl_abap_char_utilities=>horizontal_tab,

  "-- Default output filename prefix
  gc_file_prefix    TYPE string       VALUE 'SO_Lifecycle_Report'.

*----------------------------------------------------------------------*
* SELECTION SCREEN
*----------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
  "-- Sales document numbers (optional; required when date range > max days)
  SELECT-OPTIONS so_vbeln FOR vbak-vbeln MATCHCODE OBJECT H_VBAK.

  "-- Creation date range is OBLIGATORY to prevent unrestricted table scans.
  "   Validation ensures HIGH >= LOW and range <= gc_max_date_range days
  "   unless specific SO numbers are also entered.
  SELECT-OPTIONS so_erdat FOR vbak-erdat OBLIGATORY
    DEFAULT sy-datum TO sy-datum.

  "-- Optional sales document type filter (e.g. OR, ZOR)
  SELECT-OPTIONS so_auart FOR vbak-auart MATCHCODE OBJECT H_T184.
SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-002.
  "-- Output file path. Uses RLGRAP-FILENAME for ECC compatibility.
  "   Press F4 to open a GUI file-save dialog with a generated default name.
  PARAMETERS p_file TYPE rlgrap-filename DEFAULT ' '.
SELECTION-SCREEN END OF BLOCK b2.

*----------------------------------------------------------------------*
* GLOBAL DATA
*----------------------------------------------------------------------*
DATA:
  gt_so_items  TYPE STANDARD TABLE OF ty_so_item,
  gt_vbfa_dlv  TYPE STANDARD TABLE OF ty_vbfa,   "SO Item -> Delivery Item
  gt_vbfa_inv  TYPE STANDARD TABLE OF ty_vbfa,   "SO Item -> Invoice (direct billing)
  gt_vbfa_dinv TYPE STANDARD TABLE OF ty_vbfa,   "Delivery Item -> Invoice
  gt_delivs    TYPE STANDARD TABLE OF ty_deliv,
  gt_billed    TYPE STANDARD TABLE OF ty_billed,
  gt_output    TYPE STANDARD TABLE OF ty_output,
  gv_filename  TYPE string.

*----------------------------------------------------------------------*
* SELECTION SCREEN EVENTS
*----------------------------------------------------------------------*

"-- F4 help: open file-save dialog when user presses F4 on p_file
AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  PERFORM f4_file_save_dialog CHANGING p_file.

"-- Validate selection criteria before any database access
AT SELECTION-SCREEN.
  PERFORM validate_selection.

*----------------------------------------------------------------------*
* START-OF-SELECTION
*----------------------------------------------------------------------*
START-OF-SELECTION.

  "-- Test Scenario 7: Block background execution.
  "   CL_GUI_FRONTEND_SERVICES=>GUI_DOWNLOAD requires an active SAP GUI session.
  IF sy-batch = abap_true.
    MESSAGE e000(0k) WITH
      'This report must run in foreground (SAP GUI is required).'
      DISPLAY LIKE 'E'.
    LEAVE PROGRAM.
  ENDIF.

  "-- Step 1: Fetch matching sales-order items from VBAK/VBAP
  PERFORM select_so_items.

  "-- Test Scenario 10: No matching sales orders
  IF gt_so_items IS INITIAL.
    MESSAGE s000(0k) WITH 'No sales orders found for the entered selection.'
      DISPLAY LIKE 'W'.
    LEAVE PROGRAM.
  ENDIF.

  "-- Step 2: Resolve SO -> Delivery and SO/Delivery -> Invoice via VBFA
  PERFORM resolve_document_flow.

  "-- Step 3: Fetch delivery quantities from LIPS
  PERFORM select_delivery_data.

  "-- Step 4: Fetch billing amounts from VBRP + VBRK
  PERFORM select_billing_data.

  "-- Step 5: Assemble output rows (1 row per SO item / delivery / invoice combo)
  PERFORM build_output.

  IF gt_output IS INITIAL.
    MESSAGE s000(0k) WITH 'No lifecycle data rows could be assembled.'
      DISPLAY LIKE 'W'.
    LEAVE PROGRAM.
  ENDIF.

  "-- Step 6: Resolve final output filename (prompt if still blank)
  PERFORM resolve_filename.

  "-- Step 7: Download as tab-delimited UTF-8 file via SAP GUI
  PERFORM download_file.

*======================================================================*
* SUBROUTINES
*======================================================================*

*----------------------------------------------------------------------*
* FORM validate_selection
*  Validates date range bounds and selection scope before database access.
*  Test Scenario 9: Overly broad date range without SO numbers is blocked.
*----------------------------------------------------------------------*
FORM validate_selection.
  DATA: lv_high TYPE sy-datum,
        lv_diff TYPE i.

  lv_high = COND #( WHEN so_erdat-high IS INITIAL
                    THEN so_erdat-low
                    ELSE so_erdat-high ).

  IF lv_high < so_erdat-low.
    MESSAGE e000(0k) WITH 'Date High must be >= Date Low.'.
  ENDIF.

  lv_diff = lv_high - so_erdat-low.

  "-- Block excessively broad ranges unless specific SO numbers are supplied
  IF lv_diff > gc_max_date_range AND so_vbeln IS INITIAL.
    DATA lv_max_str TYPE string.
    lv_max_str = gc_max_date_range.
    MESSAGE e000(0k) WITH
      'Date range exceeds' lv_max_str
      'days. Restrict the range or enter specific Sales Document numbers.'.
  ENDIF.

  "-- Normalise HIGH date when left blank (OBLIGATORY only forces LOW entry)
  IF so_erdat-high IS INITIAL.
    so_erdat-high = lv_high.
  ENDIF.
ENDFORM.

*----------------------------------------------------------------------*
* FORM f4_file_save_dialog
*  Opens the SAP GUI file-save dialog so the user can choose a path and
*  filename. Falls back silently if the dialog is cancelled or unavailable.
*----------------------------------------------------------------------*
FORM f4_file_save_dialog CHANGING cv_file TYPE rlgrap-filename.
  DATA:
    lv_filename TYPE string,
    lv_path     TYPE string,
    lv_fullpath TYPE string,
    lv_action   TYPE i,
    lv_default  TYPE string.

  "-- Build default filename: SO_Lifecycle_Report_YYYYMMDD_HHMMSS.txt
  CONCATENATE gc_file_prefix
              '_'
              sy-datum(4) sy-datum+4(2) sy-datum+6(2)
              '_'
              sy-timlo(2) sy-timlo+2(2) sy-timlo+4(2)
              '.txt'
    INTO lv_default.

  CALL METHOD cl_gui_frontend_services=>file_save_dialog
    EXPORTING
      window_title      = 'Save Sales Order Lifecycle Report'
      default_extension = 'txt'
      default_file_name = lv_default
      initial_directory = 'C:\'
      file_filter       = 'Text Files (*.txt)|*.txt|All Files (*.*)|*.*'
    CHANGING
      filename          = lv_filename
      path              = lv_path
      fullpath          = lv_fullpath
      user_action       = lv_action
    EXCEPTIONS
      cntl_error        = 1
      error_no_gui      = 2
      OTHERS            = 3.

  IF sy-subrc = 0
    AND lv_action <> cl_gui_frontend_services=>action_cancel.
    cv_file = lv_fullpath.
  ENDIF.
ENDFORM.

*----------------------------------------------------------------------*
* FORM select_so_items
*  Reads VBAK + VBAP for sales-order items matching the selection.
*  Restricts to document category 'C' (Sales Orders only).
*  Only fetches the columns required for the final output.
*----------------------------------------------------------------------*
FORM select_so_items.

  SELECT a~vbeln a~erdat a~auart a~kunnr
         b~posnr b~matnr b~kwmeng b~vrkme
    INTO TABLE gt_so_items
    FROM vbak AS a
    INNER JOIN vbap AS b ON b~vbeln = a~vbeln
   WHERE a~erdat IN so_erdat
     AND a~vbeln IN so_vbeln
     AND a~auart IN so_auart
     AND a~vbtyp = 'C'          "Restrict to Sales Order document category
   ORDER BY a~vbeln b~posnr.    "Consistent sort order for reproducible output

  "-- Abort if result set exceeds the configured safety limit
  IF lines( gt_so_items ) > gc_max_records.
    DATA lv_max_str TYPE string.
    lv_max_str = gc_max_records.
    MESSAGE e000(0k) WITH
      'Selection returned more than' lv_max_str
      'rows. Please restrict your selection criteria.'.
  ENDIF.

ENDFORM.

*----------------------------------------------------------------------*
* FORM resolve_document_flow
*  Uses VBFA to resolve document links. No SELECT inside LOOP.
*  All FOR ALL ENTRIES calls are guarded against empty driver tables.
*
*  Pass 1: SO Item  -> Delivery Item  (category gc_vbtyp_delivery)
*          Supports Scenarios 2, 3, 4 (with/without delivery)
*  Pass 2: SO Item  -> Invoice        (category gc_vbtyp_invoice)
*          Direct billing: Scenario 6 (SO billed without a delivery)
*  Pass 3: Delivery -> Invoice        (category gc_vbtyp_invoice)
*          Delivery-related billing:  Scenario 3, 5 (standard + multi-invoice)
*
*  Duplicate Prevention:
*   - A given billing document should appear either via Pass 2 (direct)
*     OR Pass 3 (delivery-related), not both.  build_output handles
